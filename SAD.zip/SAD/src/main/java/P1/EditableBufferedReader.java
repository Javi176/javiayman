/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package P1;

/**
 *
 * @author fotop
 */
import editablebufferedreader.LineRead;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.StringBuilder;

public class EditableBufferedReader {
     public static final int INSERT;
    public static final int INICIO ;
    public static final int FIN ;
    public static final int LEFT;
    public static final int RIGHT;
    public static final int ENTER;
    public static final int BACKSPACE;
    public static final int SUPR;
    public static final int ESC; 

    
      public EditableBufferedReader(Reader in) {
        super(in);
    }

    
   public void setRaw() throws IOException {
        run("stty -echo raw < /dev/tty");
    }

    public void unsetRaw() throws IOException {
        run("stty -raw echo < /dev/tty");
    }
    
        
   
    }
    
 
    
    
    
    
    
}
